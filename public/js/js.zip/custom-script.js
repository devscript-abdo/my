jQuery(document).ready(function ($) {
    "use strict";

    $.scrollUp({
        scrollText: '<i class="fa fa-angle-up"></i>',
        easingType: 'linear',
        scrollSpeed: 900,
        animation: 'fade'
    });

    let scroller =  function()
    {
        $(window).on('scroll', function(){
            if( $(window).scrollTop()>80 ){
                $('#sticky').addClass('stick');
            } else {
                $('#sticky').removeClass('stick');
            }
        });

    };
    scroller();




    /*document.onkeydown = function(e) {
        if (e.ctrlKey &&
            (e.keyCode === 67 ||
                e.keyCode === 86 ||
                e.keyCode === 85 ||
                e.keyCode === 117)) {
            return false;
        } else {
            return true;
        }
    };
    $(document).keypress("u",function(e) {
        if(e.ctrlKey)
        {
            return false;
        }
        else
        {
            return true;
        }
    });*/

});



/***powered by Elmarzougui Abdelghafour devscript***/
